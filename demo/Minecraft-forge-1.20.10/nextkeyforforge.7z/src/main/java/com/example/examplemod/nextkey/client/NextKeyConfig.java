package com.example.examplemod.nextkey.client;

public class NextKeyConfig {
    
    /**
     * NextKey服务器地址
     * 格式: http://your-server:port 或 https://your-server:port
     * 示例: "http://localhost:8080"
     */
    public static final String SERVER_URL = "http://localhost:8080";

    /**
     * 项目UUID
     * 从NextKey管理后台获取
     * 示例: "550e8400-e29b-41d4-a716-446655440000"
     */
    public static final String PROJECT_UUID = "your-project-uuid-here";

    /**
     * AES加密密钥
     * 64位十六进制字符串（对应32字节）
     * 从NextKey管理后台获取
     * 示例: "632005a33ebb7619c1efd3853c7109f1c075c7bb86164e35da72916f9d4ef037"
     */
    public static final String AES_KEY = "your-aes-key-here";

    /**
     * 加密方案
     * 支持的值: "aes-256-gcm", "rc4", "xor", "custom-base64"
     * 推荐使用: "aes-256-gcm"
     */
    public static final String ENCRYPTION_SCHEME = "aes-256-gcm";

    /**
     * 心跳间隔（秒）
     * 建议: 300秒（5分钟）
     */
    public static final int HEARTBEAT_INTERVAL_SECONDS = 300;

    /**
     * 是否启用调试日志
     */
    public static final boolean DEBUG_MODE = false;

    /**
     * 验证配置是否有效
     * @return true表示配置有效
     */
    public static boolean isValid() {
        return !SERVER_URL.isEmpty() 
                && !PROJECT_UUID.equals("your-project-uuid-here")
                && !AES_KEY.equals("your-aes-key-here")
                && AES_KEY.length() == 64;
    }

    /**
     * 获取配置验证失败的原因
     * @return 错误信息，如果配置有效则返回null
     */
    public static String getValidationError() {
        if (SERVER_URL.isEmpty()) {
            return "服务器地址未配置";
        }
        if (PROJECT_UUID.equals("your-project-uuid-here")) {
            return "项目UUID未配置";
        }
        if (AES_KEY.equals("your-aes-key-here")) {
            return "AES密钥未配置";
        }
        if (AES_KEY.length() != 64) {
            return "AES密钥长度错误（应为64个十六进制字符）";
        }
        return null;
    }
}

