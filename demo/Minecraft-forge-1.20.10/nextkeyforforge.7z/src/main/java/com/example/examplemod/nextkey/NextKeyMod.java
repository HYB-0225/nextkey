package com.example.examplemod.nextkey;

import com.example.examplemod.nextkey.client.HeartbeatTask;
import com.example.examplemod.nextkey.client.NextKeyClient;
import com.example.examplemod.nextkey.client.NextKeyConfig;
import com.example.examplemod.nextkey.commands.NextKeyCommand;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.slf4j.Logger;

public class NextKeyMod {
    
    private static final Logger LOGGER = LogUtils.getLogger();
    private static NextKeyClient client;
    private static HeartbeatTask heartbeatTask;
    private static int messageTickCounter = 0;
    private static final int MESSAGE_INTERVAL = 100; // 每5秒显示一次提示
    private static double lastX = 0;
    private static double lastY = 0;
    private static double lastZ = 0;
    private static boolean hasInitialPosition = false;

    /**
     * 客户端设置事件
     */
    public static void onClientSetup(FMLClientSetupEvent event) {
        LOGGER.info("NextKey Mod 初始化中...");
        
        // 验证配置
        if (!NextKeyConfig.isValid()) {
            String error = NextKeyConfig.getValidationError();
            LOGGER.error("NextKey配置无效: {}", error);
            LOGGER.error("请在NextKeyConfig类中配置服务器信息");
            return;
        }

        // 创建客户端
        try {
            client = new NextKeyClient();
            LOGGER.info("NextKey客户端创建成功");
        } catch (Exception e) {
            LOGGER.error("创建NextKey客户端失败", e);
        }
    }

    /**
     * 注册客户端命令
     */
    public static void onRegisterCommands(RegisterClientCommandsEvent event) {
        NextKeyCommand.register(event.getDispatcher());
        LOGGER.info("NextKey命令已注册");
    }

    /**
     * 登录成功回调
     */
    public static void onLoginSuccess() {
        LOGGER.info("登录成功，启动心跳任务");
        
        // 启动心跳任务
        if (heartbeatTask != null) {
            heartbeatTask.stop();
        }
        heartbeatTask = new HeartbeatTask(client, NextKeyConfig.HEARTBEAT_INTERVAL_SECONDS);
        heartbeatTask.start();

        // 获取并显示项目信息
        new Thread(() -> {
            try {
                NextKeyClient.ProjectInfo projectInfo = client.getProjectInfo();
                if (projectInfo != null) {
                    LOGGER.info("项目信息: {}", projectInfo);
                }
            } catch (Exception e) {
                LOGGER.error("获取项目信息失败", e);
            }
        }).start();
    }

    /**
     * 获取客户端实例
     */
    public static NextKeyClient getClient() {
        return client;
    }

    /**
     * 获取心跳任务
     */
    public static HeartbeatTask getHeartbeatTask() {
        return heartbeatTask;
    }

    /**
     * 重新创建客户端（用于登出）
     */
    public static void recreateClient() {
        if (heartbeatTask != null) {
            heartbeatTask.stop();
            heartbeatTask = null;
        }
        
        if (client != null) {
            client.close();
        }

        try {
            client = new NextKeyClient();
            hasInitialPosition = false; // 重置位置记录
            LOGGER.info("客户端已重新创建");
        } catch (Exception e) {
            LOGGER.error("重新创建客户端失败", e);
        }
    }

    /**
     * 玩家移动事件处理
     */
    public static void onLivingUpdate(LivingEvent.LivingTickEvent event) {
        // 只处理客户端玩家
        if (event.getEntity() != Minecraft.getInstance().player) {
            return;
        }

        var player = Minecraft.getInstance().player;
        
        // 如果已登录且验证通过，更新记录的位置并允许移动
        if (client != null && client.isLoggedIn() && (heartbeatTask == null || !heartbeatTask.hasFailed())) {
            lastX = player.getX();
            lastY = player.getY();
            lastZ = player.getZ();
            hasInitialPosition = true;
            messageTickCounter = 0; // 重置消息计数器
            return;
        }

        // 未登录或验证失败，阻止移动
        if (!hasInitialPosition) {
            // 首次记录位置
            lastX = player.getX();
            lastY = player.getY();
            lastZ = player.getZ();
            hasInitialPosition = true;
        }

        // 检测是否移动了（水平移动）
        double deltaX = Math.abs(player.getX() - lastX);
        double deltaZ = Math.abs(player.getZ() - lastZ);
        
        if (deltaX > 0.001 || deltaZ > 0.001) {
            // 玩家试图移动，强制传送回原位
            player.setPos(lastX, player.getY(), lastZ);
            player.setDeltaMovement(0, player.getDeltaMovement().y, 0);
            
            // 显示提示消息
            messageTickCounter++;
            if (messageTickCounter >= MESSAGE_INTERVAL) {
                messageTickCounter = 0;
                if (client == null || !client.isLoggedIn()) {
                    player.displayClientMessage(
                        Component.literal("§c[NextKey] 请先登录才能移动！使用 /nextkey login <卡密>"),
                        true
                    );
                } else {
                    player.displayClientMessage(
                        Component.literal("§c[NextKey] 验证失败，无法移动！请重新登录"),
                        true
                    );
                }
            }
        }
    }

    /**
     * 获取验证状态
     */
    public static boolean isAuthenticated() {
        if (client == null || !client.isLoggedIn()) {
            return false;
        }
        if (heartbeatTask != null && heartbeatTask.hasFailed()) {
            return false;
        }
        return true;
    }

    /**
     * Mod关闭时清理资源
     */
    public static void shutdown() {
        if (heartbeatTask != null) {
            heartbeatTask.stop();
        }
        
        if (client != null) {
            client.close();
        }
        
        LOGGER.info("NextKey Mod 已关闭");
    }
}


