package com.example.examplemod.nextkey.utils;

import com.sun.jna.Platform;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.util.*;
import java.util.stream.Collectors;

public class HardwareIdUtil {
    
    private static String cachedHwid = null;

    /**
     * 获取硬件ID
     * 基于系统信息生成稳定的设备唯一标识
     * @return 硬件ID字符串
     */
    public static synchronized String getHardwareId() {
        if (cachedHwid != null) {
            return cachedHwid;
        }

        try {
            List<String> components = new ArrayList<>();

            // 获取主板序列号
            String motherboardSerial = getMotherboardSerial();
            if (motherboardSerial != null && !motherboardSerial.isEmpty()) {
                components.add("MB:" + motherboardSerial);
            }

            // 获取CPU信息
            String cpuInfo = getCpuInfo();
            if (cpuInfo != null && !cpuInfo.isEmpty()) {
                components.add("CPU:" + cpuInfo);
            }

            // 获取MAC地址
            String macAddress = getMacAddress();
            if (macAddress != null && !macAddress.isEmpty()) {
                components.add("MAC:" + macAddress);
            }

            // 获取磁盘序列号
            String diskSerial = getDiskSerial();
            if (diskSerial != null && !diskSerial.isEmpty()) {
                components.add("DISK:" + diskSerial);
            }

            // 如果没有获取到任何信息，使用系统属性作为后备
            if (components.isEmpty()) {
                components.add("OS:" + System.getProperty("os.name"));
                components.add("USER:" + System.getProperty("user.name"));
                components.add("ARCH:" + System.getProperty("os.arch"));
            }

            // 组合所有信息并生成哈希
            String combined = String.join("|", components);
            cachedHwid = hashString(combined);
            
            return cachedHwid;
        } catch (Exception e) {
            e.printStackTrace();
            // 如果发生错误，返回一个基于系统属性的简单ID
            cachedHwid = hashString(System.getProperty("os.name") + "|" + System.getProperty("user.name"));
            return cachedHwid;
        }
    }

    /**
     * 获取主板序列号
     */
    private static String getMotherboardSerial() {
        try {
            if (Platform.isWindows()) {
                return executeCommand("wmic baseboard get serialnumber").trim();
            } else if (Platform.isLinux()) {
                return executeCommand("sudo dmidecode -t baseboard | grep 'Serial Number'").trim();
            } else if (Platform.isMac()) {
                return executeCommand("system_profiler SPHardwareDataType | grep 'Serial Number'").trim();
            }
        } catch (Exception e) {
            // 忽略错误
        }
        return null;
    }

    /**
     * 获取CPU信息
     */
    private static String getCpuInfo() {
        try {
            if (Platform.isWindows()) {
                return executeCommand("wmic cpu get processorid").trim();
            } else if (Platform.isLinux()) {
                String cpuinfo = executeCommand("cat /proc/cpuinfo | grep 'model name' | head -n 1");
                return cpuinfo.trim();
            } else if (Platform.isMac()) {
                return executeCommand("sysctl -n machdep.cpu.brand_string").trim();
            }
        } catch (Exception e) {
            // 忽略错误
        }
        return null;
    }

    /**
     * 获取MAC地址
     */
    private static String getMacAddress() {
        try {
            InetAddress localHost = InetAddress.getLocalHost();
            NetworkInterface ni = NetworkInterface.getByInetAddress(localHost);
            
            if (ni == null) {
                // 尝试获取第一个非回环接口
                Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
                while (nis.hasMoreElements()) {
                    NetworkInterface netInterface = nis.nextElement();
                    if (!netInterface.isLoopback() && !netInterface.isVirtual() && netInterface.isUp()) {
                        ni = netInterface;
                        break;
                    }
                }
            }

            if (ni != null) {
                byte[] hardwareAddress = ni.getHardwareAddress();
                if (hardwareAddress != null && hardwareAddress.length > 0) {
                    StringBuilder sb = new StringBuilder();
                    for (byte b : hardwareAddress) {
                        sb.append(String.format("%02X", b));
                    }
                    return sb.toString();
                }
            }
        } catch (Exception e) {
            // 忽略错误
        }
        return null;
    }

    /**
     * 获取磁盘序列号
     */
    private static String getDiskSerial() {
        try {
            if (Platform.isWindows()) {
                return executeCommand("wmic diskdrive get serialnumber").trim();
            } else if (Platform.isLinux()) {
                return executeCommand("sudo hdparm -I /dev/sda | grep 'Serial Number'").trim();
            } else if (Platform.isMac()) {
                return executeCommand("diskutil info disk0 | grep 'Volume UUID'").trim();
            }
        } catch (Exception e) {
            // 忽略错误
        }
        return null;
    }

    /**
     * 执行系统命令
     */
    private static String executeCommand(String command) {
        try {
            Process process;
            if (Platform.isWindows()) {
                process = Runtime.getRuntime().exec(new String[]{"cmd", "/c", command});
            } else {
                process = Runtime.getRuntime().exec(new String[]{"/bin/sh", "-c", command});
            }
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String result = reader.lines()
                    .filter(line -> !line.trim().isEmpty())
                    .filter(line -> !line.toLowerCase().contains("serialnumber"))
                    .filter(line -> !line.toLowerCase().contains("processorid"))
                    .collect(Collectors.joining(" "));
            
            process.waitFor();
            return result;
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * 生成SHA-256哈希
     */
    private static String hashString(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            // 如果哈希失败，返回简单的字符串
            return input.replace("|", "-");
        }
    }

    /**
     * 清除缓存的硬件ID（用于测试）
     */
    public static void clearCache() {
        cachedHwid = null;
    }
}

