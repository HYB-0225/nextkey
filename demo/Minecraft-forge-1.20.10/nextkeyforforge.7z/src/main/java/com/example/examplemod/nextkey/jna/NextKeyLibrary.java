package com.example.examplemod.nextkey.jna;

import com.sun.jna.Library;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.PointerByReference;

public interface NextKeyLibrary extends Library {
    
    // 错误码常量
    int NEXTKEY_OK = 0;
    int NEXTKEY_ERR_INVALID_PARAM = -1;
    int NEXTKEY_ERR_NETWORK = -2;
    int NEXTKEY_ERR_AUTH = -401;
    int NEXTKEY_ERR_DECRYPT = -3;
    int NEXTKEY_ERR_UNKNOWN = -999;

    /**
     * 创建NextKey客户端（使用默认AES-256-GCM加密）
     * 
     * @param serverUrl 服务器地址
     * @param projectUuid 项目UUID
     * @param aesKey AES密钥（64位十六进制字符串）
     * @return 客户端实例指针，失败返回null
     */
    Pointer nextkey_client_new(String serverUrl, String projectUuid, String aesKey);

    /**
     * 创建NextKey客户端（指定加密方案）
     * 
     * @param serverUrl 服务器地址
     * @param projectUuid 项目UUID
     * @param aesKey 加密密钥
     * @param scheme 加密方案名称（"aes-256-gcm", "rc4", "xor", "custom-base64"）
     * @return 客户端实例指针，失败返回null
     */
    Pointer nextkey_client_new_with_scheme(String serverUrl, String projectUuid, String aesKey, String scheme);

    /**
     * 释放客户端资源
     * 
     * @param client 客户端实例指针
     */
    void nextkey_client_free(Pointer client);

    /**
     * 卡密登录验证
     * 
     * @param client 客户端实例指针
     * @param cardKey 卡密字符串
     * @param hwid 硬件ID
     * @param ip 客户端IP地址
     * @param tokenOut 输出访问令牌的指针
     * @param expireAtOut 输出令牌过期时间的指针
     * @param cardInfoOut 输出卡密信息的指针
     * @return 错误码
     */
    int nextkey_login(
        Pointer client,
        String cardKey,
        String hwid,
        String ip,
        PointerByReference tokenOut,
        PointerByReference expireAtOut,
        NativeStructures.NextKeyCardInfo cardInfoOut
    );

    /**
     * 发送心跳保持会话活跃
     * 
     * @param client 客户端实例指针
     * @return 错误码
     */
    int nextkey_heartbeat(Pointer client);

    /**
     * 获取云变量值
     * 
     * @param client 客户端实例指针
     * @param key 云变量键名
     * @param valueOut 输出云变量值的指针
     * @return 错误码
     */
    int nextkey_get_cloud_var(Pointer client, String key, PointerByReference valueOut);

    /**
     * 更新卡密专属信息
     * 
     * @param client 客户端实例指针
     * @param customData 要设置的专属信息字符串
     * @return 错误码
     */
    int nextkey_update_custom_data(Pointer client, String customData);

    /**
     * 获取项目信息
     * 
     * @param client 客户端实例指针
     * @param uuidOut 输出项目UUID的指针
     * @param nameOut 输出项目名称的指针
     * @param versionOut 输出项目版本号的指针
     * @param updateUrlOut 输出更新地址的指针
     * @return 错误码
     */
    int nextkey_get_project_info(
        Pointer client,
        PointerByReference uuidOut,
        PointerByReference nameOut,
        PointerByReference versionOut,
        PointerByReference updateUrlOut
    );

    /**
     * 解绑硬件ID
     * 
     * @param client 客户端实例指针
     * @param cardKey 要解绑的卡密字符串
     * @param hwid 要解绑的硬件ID
     * @return 错误码
     */
    int nextkey_unbind_hwid(Pointer client, String cardKey, String hwid);

    /**
     * 获取最后的错误消息
     * 
     * @return 错误消息字符串指针（不需要释放）
     */
    Pointer nextkey_get_last_error();

    /**
     * 释放由SDK分配的C字符串
     * 
     * @param s 需要释放的字符串指针
     */
    void nextkey_free_string(Pointer s);

    /**
     * 释放卡密信息结构体内部的字符串
     * 
     * @param cardInfo 指向NextKeyCardInfo结构体的指针
     */
    void nextkey_free_card_info(NativeStructures.NextKeyCardInfo cardInfo);
}

