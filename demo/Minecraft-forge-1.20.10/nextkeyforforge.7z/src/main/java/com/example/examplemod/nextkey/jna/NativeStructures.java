package com.example.examplemod.nextkey.jna;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

public class NativeStructures {
    
    /**
     * 卡密信息结构体
     * 对应C结构体 NextKeyCardInfo
     */
    @Structure.FieldOrder({"id", "cardKey", "activated", "duration", "customData"})
    public static class NextKeyCardInfo extends Structure {
        public long id;
        public Pointer cardKey;
        public int activated;
        public long duration;
        public Pointer customData;

        public NextKeyCardInfo() {
            super();
        }

        public NextKeyCardInfo(Pointer p) {
            super(p);
            read();
        }

        /**
         * 获取卡密字符串
         * @return 卡密字符串，如果为null则返回空字符串
         */
        public String getCardKey() {
            return cardKey != null ? cardKey.getString(0, "UTF-8") : "";
        }

        /**
         * 获取专属信息字符串
         * @return 专属信息字符串，如果为null则返回空字符串
         */
        public String getCustomData() {
            return customData != null ? customData.getString(0, "UTF-8") : "";
        }

        /**
         * 是否已激活
         * @return true表示已激活
         */
        public boolean isActivated() {
            return activated != 0;
        }

        @Override
        public String toString() {
            return "NextKeyCardInfo{" +
                    "id=" + id +
                    ", cardKey='" + getCardKey() + '\'' +
                    ", activated=" + isActivated() +
                    ", duration=" + duration +
                    ", customData='" + getCustomData() + '\'' +
                    '}';
        }
    }
}

