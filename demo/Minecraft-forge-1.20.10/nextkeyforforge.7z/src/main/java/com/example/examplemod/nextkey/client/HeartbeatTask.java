package com.example.examplemod.nextkey.client;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class HeartbeatTask {
    
    private static final Logger LOGGER = LogUtils.getLogger();
    private final NextKeyClient client;
    private final int intervalSeconds;
    private ScheduledExecutorService scheduler;
    private ScheduledFuture<?> heartbeatFuture;
    private boolean running = false;
    private boolean failed = false;

    public HeartbeatTask(NextKeyClient client, int intervalSeconds) {
        this.client = client;
        this.intervalSeconds = intervalSeconds;
    }

    /**
     * 启动心跳任务
     */
    public synchronized void start() {
        if (running) {
            LOGGER.warn("心跳任务已经在运行");
            return;
        }

        if (!client.isLoggedIn()) {
            LOGGER.warn("客户端未登录，无法启动心跳");
            return;
        }

        failed = false; // 重置失败状态
        
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread thread = new Thread(r, "NextKey-Heartbeat");
            thread.setDaemon(true);
            return thread;
        });

        heartbeatFuture = scheduler.scheduleAtFixedRate(
            this::sendHeartbeat,
            intervalSeconds,
            intervalSeconds,
            TimeUnit.SECONDS
        );

        running = true;
        LOGGER.info("心跳任务已启动，间隔: {} 秒", intervalSeconds);
    }

    /**
     * 停止心跳任务
     */
    public synchronized void stop() {
        if (!running) {
            return;
        }

        if (heartbeatFuture != null) {
            heartbeatFuture.cancel(false);
            heartbeatFuture = null;
        }

        if (scheduler != null) {
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
            scheduler = null;
        }

        running = false;
        LOGGER.info("心跳任务已停止");
    }

    /**
     * 是否正在运行
     */
    public boolean isRunning() {
        return running;
    }

    /**
     * 心跳是否失败
     */
    public boolean hasFailed() {
        return failed;
    }

    /**
     * 发送心跳
     */
    private void sendHeartbeat() {
        try {
            if (!client.isLoggedIn()) {
                LOGGER.warn("客户端未登录，停止心跳");
                failed = true;
                stop();
                return;
            }

            boolean success = client.heartbeat();
            if (success) {
                failed = false;
                if (NextKeyConfig.DEBUG_MODE) {
                    LOGGER.info("心跳成功");
                }
            } else {
                LOGGER.error("心跳失败，可能需要重新登录");
                failed = true;
                stop();
            }
        } catch (Exception e) {
            LOGGER.error("心跳异常", e);
            failed = true;
        }
    }

    /**
     * 手动触发一次心跳（用于测试）
     */
    public void triggerHeartbeat() {
        sendHeartbeat();
    }
}

