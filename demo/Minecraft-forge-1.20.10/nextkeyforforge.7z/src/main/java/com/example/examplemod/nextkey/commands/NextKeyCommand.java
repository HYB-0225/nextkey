package com.example.examplemod.nextkey.commands;

import com.example.examplemod.nextkey.NextKeyMod;
import com.example.examplemod.nextkey.client.NextKeyClient;
import com.example.examplemod.nextkey.utils.HardwareIdUtil;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public class NextKeyCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("nextkey")
                .then(Commands.literal("login")
                    .then(Commands.argument("cardkey", StringArgumentType.string())
                        .executes(ctx -> loginWithCardKey(ctx, StringArgumentType.getString(ctx, "cardkey")))
                    )
                )
                .then(Commands.literal("status")
                    .executes(NextKeyCommand::showStatus)
                )
                .then(Commands.literal("cloudvar")
                    .then(Commands.argument("key", StringArgumentType.string())
                        .executes(ctx -> getCloudVar(ctx, StringArgumentType.getString(ctx, "key")))
                    )
                )
                .then(Commands.literal("heartbeat")
                    .executes(NextKeyCommand::sendHeartbeat)
                )
                .then(Commands.literal("unbind")
                    .then(Commands.argument("hwid", StringArgumentType.string())
                        .executes(ctx -> unbindHwid(ctx, StringArgumentType.getString(ctx, "hwid")))
                    )
                )
                .then(Commands.literal("hwid")
                    .executes(NextKeyCommand::showHwid)
                )
                .then(Commands.literal("logout")
                    .executes(NextKeyCommand::logout)
                )
        );
    }

    private static int loginWithCardKey(CommandContext<CommandSourceStack> ctx, String cardKey) {
        NextKeyClient client = NextKeyMod.getClient();
        if (client == null) {
            ctx.getSource().sendFailure(Component.literal("§cNextKey客户端未初始化"));
            return 0;
        }

        ctx.getSource().sendSuccess(() -> Component.literal("§e正在登录..."), false);

        new Thread(() -> {
            try {
                String hwid = HardwareIdUtil.getHardwareId();
                NextKeyClient.LoginResult result = client.login(cardKey, hwid, "");
                
                Minecraft.getInstance().execute(() -> {
                    if (result.success) {
                        ctx.getSource().sendSuccess(() -> Component.literal("§a登录成功！"), false);
                        ctx.getSource().sendSuccess(() -> Component.literal("§7卡密ID: " + result.cardInfo.id), false);
                        ctx.getSource().sendSuccess(() -> Component.literal("§7有效期: " + result.cardInfo.duration + "秒"), false);
                        
                        // 调用登录成功回调
                        NextKeyMod.onLoginSuccess();
                    } else {
                        ctx.getSource().sendFailure(Component.literal("§c登录失败: " + result.message));
                    }
                });
            } catch (Exception e) {
                Minecraft.getInstance().execute(() -> {
                    ctx.getSource().sendFailure(Component.literal("§c登录异常: " + e.getMessage()));
                });
            }
        }).start();

        return 1;
    }

    private static int showStatus(CommandContext<CommandSourceStack> ctx) {
        NextKeyClient client = NextKeyMod.getClient();
        if (client == null) {
            ctx.getSource().sendFailure(Component.literal("§cNextKey客户端未初始化"));
            return 0;
        }

        if (client.isLoggedIn()) {
            NextKeyClient.CardInfo info = client.getCardInfo();
            ctx.getSource().sendSuccess(() -> Component.literal("§a状态: 已登录"), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7卡密: " + info.cardKey), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7激活状态: " + (info.activated ? "已激活" : "未激活")), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7有效期: " + info.duration + "秒"), false);
            if (!info.customData.isEmpty()) {
                ctx.getSource().sendSuccess(() -> Component.literal("§7专属信息: " + info.customData), false);
            }
        } else {
            ctx.getSource().sendSuccess(() -> Component.literal("§e状态: 未登录"), false);
        }

        return 1;
    }

    private static int getCloudVar(CommandContext<CommandSourceStack> ctx, String key) {
        NextKeyClient client = NextKeyMod.getClient();
        if (client == null) {
            ctx.getSource().sendFailure(Component.literal("§cNextKey客户端未初始化"));
            return 0;
        }

        if (!client.isLoggedIn()) {
            ctx.getSource().sendFailure(Component.literal("§c请先登录"));
            return 0;
        }

        new Thread(() -> {
            String value = client.getCloudVar(key);
            Minecraft.getInstance().execute(() -> {
                if (value != null) {
                    ctx.getSource().sendSuccess(() -> Component.literal("§a云变量 [" + key + "]: §f" + value), false);
                } else {
                    ctx.getSource().sendFailure(Component.literal("§c获取云变量失败"));
                }
            });
        }).start();

        return 1;
    }

    private static int sendHeartbeat(CommandContext<CommandSourceStack> ctx) {
        NextKeyClient client = NextKeyMod.getClient();
        if (client == null) {
            ctx.getSource().sendFailure(Component.literal("§cNextKey客户端未初始化"));
            return 0;
        }

        if (!client.isLoggedIn()) {
            ctx.getSource().sendFailure(Component.literal("§c请先登录"));
            return 0;
        }

        new Thread(() -> {
            boolean success = client.heartbeat();
            Minecraft.getInstance().execute(() -> {
                if (success) {
                    ctx.getSource().sendSuccess(() -> Component.literal("§a心跳成功"), false);
                } else {
                    ctx.getSource().sendFailure(Component.literal("§c心跳失败"));
                }
            });
        }).start();

        return 1;
    }

    private static int unbindHwid(CommandContext<CommandSourceStack> ctx, String hwid) {
        NextKeyClient client = NextKeyMod.getClient();
        if (client == null) {
            ctx.getSource().sendFailure(Component.literal("§cNextKey客户端未初始化"));
            return 0;
        }

        if (!client.isLoggedIn()) {
            ctx.getSource().sendFailure(Component.literal("§c请先登录"));
            return 0;
        }

        NextKeyClient.CardInfo info = client.getCardInfo();
        new Thread(() -> {
            boolean success = client.unbindHwid(info.cardKey, hwid);
            Minecraft.getInstance().execute(() -> {
                if (success) {
                    ctx.getSource().sendSuccess(() -> Component.literal("§a解绑成功"), false);
                } else {
                    ctx.getSource().sendFailure(Component.literal("§c解绑失败"));
                }
            });
        }).start();

        return 1;
    }

    private static int showHwid(CommandContext<CommandSourceStack> ctx) {
        String hwid = HardwareIdUtil.getHardwareId();
        ctx.getSource().sendSuccess(() -> Component.literal("§a当前硬件ID: §f" + hwid), false);
        return 1;
    }

    private static int logout(CommandContext<CommandSourceStack> ctx) {
        NextKeyMod.recreateClient();
        ctx.getSource().sendSuccess(() -> Component.literal("§a已登出"), false);
        return 1;
    }
}

