package com.example.examplemod.nextkey.jna;

import com.sun.jna.Native;
import com.sun.jna.Platform;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class LibraryLoader {
    
    private static NextKeyLibrary instance;
    private static boolean loaded = false;
    private static String loadError = null;

    /**
     * 获取NextKey库实例
     * @return NextKey库实例，如果加载失败则返回null
     */
    public static synchronized NextKeyLibrary getInstance() {
        if (!loaded) {
            try {
                loadLibrary();
                loaded = true;
            } catch (Exception e) {
                loadError = "加载NextKey库失败: " + e.getMessage();
                e.printStackTrace();
                return null;
            }
        }
        return instance;
    }

    /**
     * 检查库是否已加载
     * @return true表示已成功加载
     */
    public static boolean isLoaded() {
        return loaded && instance != null;
    }

    /**
     * 获取加载错误信息
     * @return 错误信息，如果没有错误则返回null
     */
    public static String getLoadError() {
        return loadError;
    }

    /**
     * 加载动态库
     */
    private static void loadLibrary() throws IOException {
        String libraryName = getLibraryName();
        String resourcePath = getResourcePath();

        // 从资源中提取动态库到临时目录
        InputStream libStream = LibraryLoader.class.getResourceAsStream(resourcePath);
        if (libStream == null) {
            throw new FileNotFoundException("找不到动态库资源: " + resourcePath);
        }

        // 创建临时文件
        Path tempDir = Files.createTempDirectory("nextkey-native");
        tempDir.toFile().deleteOnExit();
        
        Path tempLibFile = tempDir.resolve(libraryName);
        tempLibFile.toFile().deleteOnExit();

        // 复制库文件到临时目录
        try (InputStream in = libStream;
             OutputStream out = Files.newOutputStream(tempLibFile)) {
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }

        // 加载库
        System.setProperty("jna.library.path", tempDir.toString());
        instance = Native.load(getLibraryBaseName(), NextKeyLibrary.class);
    }

    /**
     * 获取库文件名
     */
    private static String getLibraryName() {
        if (Platform.isWindows()) {
            return "nextkey_sdk.dll";
        } else if (Platform.isLinux()) {
            return "libnextkey_sdk.so";
        } else if (Platform.isMac()) {
            return "libnextkey_sdk.dylib";
        } else {
            throw new UnsupportedOperationException("不支持的操作系统: " + System.getProperty("os.name"));
        }
    }

    /**
     * 获取库基础名（不含前缀和后缀）
     */
    private static String getLibraryBaseName() {
        return "nextkey_sdk";
    }

    /**
     * 获取资源路径
     */
    private static String getResourcePath() {
        String osDir;
        if (Platform.isWindows()) {
            osDir = "windows";
        } else if (Platform.isLinux()) {
            osDir = "linux";
        } else if (Platform.isMac()) {
            osDir = "macos";
        } else {
            throw new UnsupportedOperationException("不支持的操作系统");
        }
        
        return "/natives/" + osDir + "/" + getLibraryName();
    }
}

