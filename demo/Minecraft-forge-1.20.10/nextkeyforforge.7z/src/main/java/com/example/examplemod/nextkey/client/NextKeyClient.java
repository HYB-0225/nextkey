package com.example.examplemod.nextkey.client;

import com.example.examplemod.nextkey.jna.LibraryLoader;
import com.example.examplemod.nextkey.jna.NativeStructures;
import com.example.examplemod.nextkey.jna.NextKeyLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.PointerByReference;

public class NextKeyClient {
    
    private Pointer clientPtr;
    private final NextKeyLibrary library;
    private String token;
    private CardInfo cardInfo;
    private boolean loggedIn = false;

    /**
     * 创建NextKey客户端（使用配置类）
     */
    public NextKeyClient() throws Exception {
        this(NextKeyConfig.SERVER_URL, NextKeyConfig.PROJECT_UUID, NextKeyConfig.AES_KEY, NextKeyConfig.ENCRYPTION_SCHEME);
    }

    /**
     * 创建NextKey客户端
     * @param serverUrl 服务器地址
     * @param projectUuid 项目UUID
     * @param aesKey AES密钥
     * @param scheme 加密方案
     */
    public NextKeyClient(String serverUrl, String projectUuid, String aesKey, String scheme) throws Exception {
        library = LibraryLoader.getInstance();
        if (library == null) {
            throw new Exception("无法加载NextKey库: " + LibraryLoader.getLoadError());
        }

        clientPtr = library.nextkey_client_new_with_scheme(serverUrl, projectUuid, aesKey, scheme);
        if (clientPtr == null) {
            String error = getLastError();
            throw new Exception("创建客户端失败: " + error);
        }
    }

    /**
     * 卡密登录
     * @param cardKey 卡密
     * @param hwid 硬件ID
     * @param ip IP地址（可为空）
     * @return 登录结果
     */
    public LoginResult login(String cardKey, String hwid, String ip) {
        if (clientPtr == null) {
            return new LoginResult(false, "客户端未初始化", null, null, null);
        }

        PointerByReference tokenOut = new PointerByReference();
        PointerByReference expireAtOut = new PointerByReference();
        NativeStructures.NextKeyCardInfo cardInfoStruct = new NativeStructures.NextKeyCardInfo();

        int result = library.nextkey_login(clientPtr, cardKey, hwid, ip, tokenOut, expireAtOut, cardInfoStruct);
        
        if (result == NextKeyLibrary.NEXTKEY_OK) {
            token = tokenOut.getValue().getString(0, "UTF-8");
            String expireAt = expireAtOut.getValue().getString(0, "UTF-8");
            
            cardInfo = new CardInfo(
                cardInfoStruct.id,
                cardInfoStruct.getCardKey(),
                cardInfoStruct.isActivated(),
                cardInfoStruct.duration,
                cardInfoStruct.getCustomData()
            );
            
            // 释放原生内存
            library.nextkey_free_string(tokenOut.getValue());
            library.nextkey_free_string(expireAtOut.getValue());
            library.nextkey_free_card_info(cardInfoStruct);
            
            loggedIn = true;
            return new LoginResult(true, "登录成功", token, expireAt, cardInfo);
        } else {
            String error = getLastError();
            return new LoginResult(false, error != null ? error : "未知错误(代码:" + result + ")", null, null, null);
        }
    }

    /**
     * 发送心跳
     * @return true表示成功
     */
    public boolean heartbeat() {
        if (clientPtr == null || !loggedIn) {
            return false;
        }

        int result = library.nextkey_heartbeat(clientPtr);
        return result == NextKeyLibrary.NEXTKEY_OK;
    }

    /**
     * 获取云变量
     * @param key 变量键名
     * @return 变量值，失败返回null
     */
    public String getCloudVar(String key) {
        if (clientPtr == null || !loggedIn) {
            return null;
        }

        PointerByReference valueOut = new PointerByReference();
        int result = library.nextkey_get_cloud_var(clientPtr, key, valueOut);
        
        if (result == NextKeyLibrary.NEXTKEY_OK) {
            String value = valueOut.getValue().getString(0, "UTF-8");
            library.nextkey_free_string(valueOut.getValue());
            return value;
        }
        
        return null;
    }

    /**
     * 更新专属信息
     * @param customData 专属信息
     * @return true表示成功
     */
    public boolean updateCustomData(String customData) {
        if (clientPtr == null || !loggedIn) {
            return false;
        }

        int result = library.nextkey_update_custom_data(clientPtr, customData);
        return result == NextKeyLibrary.NEXTKEY_OK;
    }

    /**
     * 获取项目信息
     * @return 项目信息，失败返回null
     */
    public ProjectInfo getProjectInfo() {
        if (clientPtr == null || !loggedIn) {
            return null;
        }

        PointerByReference uuidOut = new PointerByReference();
        PointerByReference nameOut = new PointerByReference();
        PointerByReference versionOut = new PointerByReference();
        PointerByReference updateUrlOut = new PointerByReference();

        int result = library.nextkey_get_project_info(clientPtr, uuidOut, nameOut, versionOut, updateUrlOut);
        
        if (result == NextKeyLibrary.NEXTKEY_OK) {
            String uuid = uuidOut.getValue().getString(0, "UTF-8");
            String name = nameOut.getValue().getString(0, "UTF-8");
            String version = versionOut.getValue().getString(0, "UTF-8");
            String updateUrl = updateUrlOut.getValue().getString(0, "UTF-8");
            
            library.nextkey_free_string(uuidOut.getValue());
            library.nextkey_free_string(nameOut.getValue());
            library.nextkey_free_string(versionOut.getValue());
            library.nextkey_free_string(updateUrlOut.getValue());
            
            return new ProjectInfo(uuid, name, version, updateUrl);
        }
        
        return null;
    }

    /**
     * 解绑硬件ID
     * @param cardKey 卡密
     * @param hwid 要解绑的硬件ID
     * @return true表示成功
     */
    public boolean unbindHwid(String cardKey, String hwid) {
        if (clientPtr == null || !loggedIn) {
            return false;
        }

        int result = library.nextkey_unbind_hwid(clientPtr, cardKey, hwid);
        return result == NextKeyLibrary.NEXTKEY_OK;
    }

    /**
     * 是否已登录
     */
    public boolean isLoggedIn() {
        return loggedIn;
    }

    /**
     * 获取Token
     */
    public String getToken() {
        return token;
    }

    /**
     * 获取卡密信息
     */
    public CardInfo getCardInfo() {
        return cardInfo;
    }

    /**
     * 获取最后的错误信息
     */
    public String getLastError() {
        if (library == null) {
            return "库未加载";
        }
        Pointer errorPtr = library.nextkey_get_last_error();
        if (errorPtr == null) {
            return null;
        }
        return errorPtr.getString(0, "UTF-8");
    }

    /**
     * 关闭客户端
     */
    public void close() {
        if (clientPtr != null && library != null) {
            library.nextkey_client_free(clientPtr);
            clientPtr = null;
            loggedIn = false;
        }
    }

    @Override
    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }

    // 内部类
    public static class LoginResult {
        public final boolean success;
        public final String message;
        public final String token;
        public final String expireAt;
        public final CardInfo cardInfo;

        public LoginResult(boolean success, String message, String token, String expireAt, CardInfo cardInfo) {
            this.success = success;
            this.message = message;
            this.token = token;
            this.expireAt = expireAt;
            this.cardInfo = cardInfo;
        }
    }

    public static class CardInfo {
        public final long id;
        public final String cardKey;
        public final boolean activated;
        public final long duration;
        public final String customData;

        public CardInfo(long id, String cardKey, boolean activated, long duration, String customData) {
            this.id = id;
            this.cardKey = cardKey;
            this.activated = activated;
            this.duration = duration;
            this.customData = customData;
        }

        @Override
        public String toString() {
            return "CardInfo{" +
                    "id=" + id +
                    ", cardKey='" + cardKey + '\'' +
                    ", activated=" + activated +
                    ", duration=" + duration +
                    ", customData='" + customData + '\'' +
                    '}';
        }
    }

    public static class ProjectInfo {
        public final String uuid;
        public final String name;
        public final String version;
        public final String updateUrl;

        public ProjectInfo(String uuid, String name, String version, String updateUrl) {
            this.uuid = uuid;
            this.name = name;
            this.version = version;
            this.updateUrl = updateUrl;
        }

        @Override
        public String toString() {
            return "ProjectInfo{" +
                    "uuid='" + uuid + '\'' +
                    ", name='" + name + '\'' +
                    ", version='" + version + '\'' +
                    ", updateUrl='" + updateUrl + '\'' +
                    '}';
        }
    }
}

