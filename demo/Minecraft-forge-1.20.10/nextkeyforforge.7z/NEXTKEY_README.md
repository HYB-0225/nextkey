# NextKey Forge Mod

这是一个集成了NextKey卡密验证系统的Minecraft Forge Mod基础模板。

## 功能特性

- **卡密登录验证** - 纯命令行登录方式
- **硬件ID绑定** - 自动获取硬件ID进行设备绑定
- **移动限制** - 未登录或验证失败时完全阻止玩家移动
- **心跳保活** - 自动定期发送心跳保持会话活跃
- **云变量** - 支持从服务器获取云变量配置
- **命令系统** - 提供完整的命令行接口

## 配置说明

在使用前，需要在 `src/main/java/com/example/examplemod/nextkey/client/NextKeyConfig.java` 中配置：

```java
public static final String SERVER_URL = "http://your-server:8080";
public static final String PROJECT_UUID = "your-project-uuid-here";
public static final String AES_KEY = "your-aes-key-here";
```

配置项说明：
- `SERVER_URL`: NextKey服务器地址
- `PROJECT_UUID`: 从NextKey管理后台获取的项目UUID
- `AES_KEY`: 64位十六进制AES密钥（从管理后台获取）
- `ENCRYPTION_SCHEME`: 加密方案，推荐使用 "aes-256-gcm"
- `HEARTBEAT_INTERVAL_SECONDS`: 心跳间隔（秒）

## 可用命令

```
/nextkey login <卡密>   - 使用卡密登录（必须提供卡密参数）
/nextkey status         - 查看登录状态和卡密信息
/nextkey cloudvar <key> - 获取云变量
/nextkey heartbeat      - 手动发送心跳
/nextkey unbind <hwid>  - 解绑指定硬件ID
/nextkey hwid           - 显示当前硬件ID
/nextkey logout         - 登出并重置验证状态
```

## 验证机制

本Mod实现了严格的验证机制作为演示：

1. **未登录限制**
   - 进入游戏后，玩家无法进行水平移动（WASD键无效）
   - 屏幕上会显示提示：`[NextKey] 请先登录才能移动！使用 /nextkey login <卡密>`
   - 仍可跳跃和查看周围

2. **登录后解锁**
   - 使用 `/nextkey login <卡密>` 命令登录成功后
   - 移动限制立即解除，可以正常游戏
   - 自动启动心跳任务，每5分钟向服务器验证一次

3. **心跳失败保护**
   - 如果心跳验证失败（服务器不可达、卡密过期等）
   - 玩家再次被冻结，无法移动
   - 显示提示：`[NextKey] 验证失败，无法移动！请重新登录`

## 技术架构

### 目录结构

```
src/main/java/com/example/examplemod/nextkey/
├── NextKeyMod.java              # 主模块（包含移动限制逻辑）
├── client/
│   ├── NextKeyClient.java       # Java客户端封装
│   ├── NextKeyConfig.java       # 配置类
│   └── HeartbeatTask.java       # 心跳任务（带失败状态追踪）
├── jna/
│   ├── NextKeyLibrary.java      # JNA接口定义
│   ├── NativeStructures.java    # C结构体映射
│   └── LibraryLoader.java       # 动态库加载器
├── utils/
│   └── HardwareIdUtil.java      # 硬件ID获取
└── commands/
    └── NextKeyCommand.java      # 命令处理
```

### 工作流程

1. **初始化**: Mod启动时创建NextKey客户端实例
2. **移动冻结**: 玩家进入游戏后被冻结在原位，无法移动
3. **登录验证**: 用户通过命令输入卡密进行登录
4. **验证成功**: 使用硬件ID和卡密向服务器验证，成功后解除移动限制
5. **心跳保持**: 登录成功后自动启动心跳任务保持会话
6. **持续验证**: 心跳失败会重新冻结玩家，需要重新登录

## 编译说明

1. 确保已编译Rust SDK:
```bash
cd rust-sdk
cargo build --release
```

2. 编译Mod:
```bash
./gradlew build
```

编译后的文件位于 `build/libs/`

## 依赖项

- Minecraft Forge 1.21.10-60.0.13
- JNA 5.13.0
- Rust SDK (编译为动态库)

## 注意事项

1. **配置要求**: 配置文件中的密钥必须与NextKey服务器配置一致
2. **动态库**: 已打包在mod的resources目录中，会自动提取和加载
3. **首次运行**: 如果配置未设置会在日志中提示错误
4. **心跳机制**: 心跳失败会自动停止心跳任务并冻结玩家，需要重新登录
5. **验证演示**: 移动限制功能仅作为验证机制的演示，实际使用中可根据需求调整

## 开发者说明

如果要在其他mod中使用此mod作为库，可以：

```java
// 获取客户端实例
NextKeyClient client = NextKeyMod.getClient();

// 检查登录状态
if (client != null && client.isLoggedIn()) {
    // 使用客户端功能
    String value = client.getCloudVar("key");
}
```

## 许可证

根据项目LICENSE.txt

